﻿using System;
using System.Collections.Generic;
using System.Xml;

public class SAXWrapper
{
    private string directory;

    public void SetDirectory(string arg) {
        directory = arg;
    }

    private string fileName;

    public void SetFileName(string arg) {
        fileName = arg;
    }

    private string GetFullPath() {
        if (string.IsNullOrEmpty(directory)) {
            throw new ArgumentException(@"Directory is not assigned.");
        }
        if (string.IsNullOrEmpty(fileName)) {
            throw new ArgumentException(@"File is not assigned.");
        }
        return directory + @"\" + fileName;
    }

    private NodeEntity node;

    public NodeEntity GetNode() {
        return node;
    }

    private int currentNodeId;

    public SAXWrapper() {
        currentNodeId = 0;
    }

    public void Parse() {
        System.IO.StreamReader sr = new System.IO.StreamReader(GetFullPath());
        XmlReaderSettings settings = new XmlReaderSettings();
        XmlReader reader = XmlReader.Create(sr, settings);
        try {
            List<string> tree = new List<string>();
            while (reader.Read()) {
                ParseElement(reader, tree);
                ParseText(reader, tree);
                ParseCDATA(reader, tree);
                ParseEndElement(reader, tree);
            }
        } catch (Exception) {
            throw;
        } finally {
            if (reader != null) {
                reader.Close();
            }
            if (sr != null) {
                sr.Close();
            }
        }
    }

    private void ParseElement(XmlReader reader, List<string> tree) {
        if (reader.NodeType != XmlNodeType.Element) {
            return;
        }
        string nodeName = reader.Name;
        NodeEntity newNode = new NodeEntity();
        newNode.SetNodeName(nodeName);
        newNode.SetNodeID(currentNodeId);
        currentNodeId++;
        ParseAttributes(reader, newNode);
        if (currentNodeId == 1) {
            node = newNode;
        } else {
            node.FindFromTail(tree).AddChild(newNode);
        }
        if (!reader.IsEmptyElement) {
            tree.Add(nodeName);
        }
    }

    private void ParseText(XmlReader reader, List<string> tree) {
        if (reader.NodeType != XmlNodeType.Text) {
            return;
        }
        string value = reader.Value;
        if (!string.IsNullOrEmpty(value)) {
            node.FindFromTail(tree).SetNodeValue(value);
        }
    }

    private void ParseCDATA(XmlReader reader, List<string> tree) {
        if (reader.NodeType != XmlNodeType.CDATA) {
            return;
        }
        string value = reader.Value;
        if (!string.IsNullOrEmpty(value)) {
            node.FindFromTail(tree).SetNodeValue(value);
        }
    }

    private void ParseEndElement(XmlReader reader, List<string> tree) {
        if (reader.NodeType != XmlNodeType.EndElement) {
            return;
        }
        tree.RemoveAt(tree.Count - 1);
    }

    private void ParseAttributes(XmlReader reader, NodeEntity currentNode) {
        int iLoopCount = reader.AttributeCount;
        for (int i = 0; i < iLoopCount; i++) {
            reader.MoveToAttribute(i);
            string attrName = reader.LocalName;
            string attrValue = reader.GetAttribute(attrName);
            AttributeEntity attr = new AttributeEntity();
            attr.SetAttrName(attrName);
            attr.SetAttrValue(attrValue);
            currentNode.AddAttr(attr);
        }
    }
}