﻿public class AttributeEntity
{
    private string attrName;

    public void SetAttrName(string arg) {
        attrName = arg;
    }

    public string GetAttrName() {
        return attrName;
    }

    private string attrValue;

    public void SetAttrValue(string arg) {
        attrValue = arg;
    }

    public string GetAttrValue() {
        return attrValue;
    }

    public bool NameEquals(string arg) {
        if (attrName.Equals(arg)) {
            return true;
        } else {
            return false;
        }
    }

    public bool ValueEquals(string arg) {
        if (attrValue.Equals(arg)) {
            return true;
        } else {
            return false;
        }
    }

    public AttributeEntity Clone() {
        AttributeEntity ret = new AttributeEntity();
        ret.SetAttrName(attrName);
        ret.SetAttrValue(attrValue);
        return ret;
    }
}