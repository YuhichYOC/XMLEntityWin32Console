﻿using System.Collections.Generic;

public class NodeEntity
{
    private string nodeName;

    public void SetNodeName(string arg) {
        nodeName = arg;
    }

    public string GetNodeName() {
        return nodeName;
    }

    private int nodeId;

    public void SetNodeID(int arg) {
        nodeId = arg;
    }

    public int GetNodeID() {
        return nodeId;
    }

    private string nodeValue;

    public void SetNodeValue(string arg) {
        nodeValue = arg;
    }

    public string GetNodeValue() {
        return nodeValue;
    }

    private List<AttributeEntity> attrList;

    public void SetAttrList(List<AttributeEntity> arg) {
        attrList = arg;
    }

    public List<AttributeEntity> GetAttrList() {
        return attrList;
    }

    public void AddAttr(AttributeEntity arg) {
        attrList.Add(arg);
    }

    private List<NodeEntity> childList;

    public void SetChildList(List<NodeEntity> arg) {
        childList = arg;
    }

    public List<NodeEntity> GetChildList() {
        return childList;
    }

    public void AddChild(NodeEntity arg) {
        childList.Add(arg);
    }

    public NodeEntity() {
        attrList = new List<AttributeEntity>();
        childList = new List<NodeEntity>();
    }

    public bool AttrExists(string name) {
        bool ret = false;
        attrList.ForEach(v => {
            if (v.NameEquals(name)) {
                ret = true;
            }
        });
        return ret;
    }

    public string AttrByName(string name) {
        string ret = @"";
        attrList.ForEach(v => {
            if (v.NameEquals(name)) {
                ret = v.GetAttrValue();
            }
        });
        return ret;
    }

    public bool NameEquals(string name) {
        if (nodeName.Equals(name)) {
            return true;
        } else {
            return false;
        }
    }

    public NodeEntity Find(string tagName) {
        NodeEntity ret = null;
        childList.ForEach(v => {
            if (v.NameEquals(tagName)) {
                ret = v;
            }
        });
        return ret;
    }

    public NodeEntity Find(string tagName, string attrName, string attrValue) {
        NodeEntity ret = null;
        childList.ForEach(v => {
            if (v.NameEquals(tagName) && v.AttrExists(attrName) && v.AttrByName(attrName).Equals(attrValue)) {
                ret = v;
            }
        });
        return ret;
    }

    public NodeEntity Find(string tagName, string attr1Name, string attr1Value, string attr2Name, string attr2Value) {
        NodeEntity ret = null;
        childList.ForEach(v => {
            if (v.NameEquals(tagName)
             && v.AttrExists(attr1Name)
             && v.AttrByName(attr1Name).Equals(attr1Value)
             && v.AttrExists(attr2Name)
             && v.AttrByName(attr2Name).Equals(attr2Value)) {
                ret = v;
            }
        });
        return ret;
    }

    public NodeEntity FindFromTail(List<string> tree) {
        NodeEntity node = this;
        if (tree.Count <= 1) {
            return node;
        } else {
            List<string> subtree = new List<string>();
            tree.ForEach(v => { subtree.Add(v); });
            subtree.RemoveAt(0);
            return FindFromTail(node, subtree);
        }
    }

    public NodeEntity FindFromTail(List<string> tree, string leafName) {
        NodeEntity node = this;
        if (tree.Count <= 0) {
            return node;
        } else {
            if (string.IsNullOrEmpty(leafName)) {
                return FindFromTail(tree);
            } else {
                List<string> subtree = new List<string>();
                tree.ForEach(v => { subtree.Add(v); });
                subtree.RemoveAt(0);
                return FindFromTail(node, subtree, leafName);
            }
        }
    }

    private NodeEntity FindFromTail(NodeEntity node, List<string> tree) {
        if (node == null) {
            node = this;
        }
        if (tree.Count == 0) {
            return node;
        }
        int pos = FindChildIndexByName(node, tree[0]);
        tree.RemoveAt(0);
        if (pos >= 0) {
            return FindFromTail(node.GetChildList()[pos], tree);
        } else {
            return null;
        }
    }

    private NodeEntity FindFromTail(NodeEntity node, List<string> tree, string leafName) {
        if (node == null) {
            node = this;
        }
        if (tree.Count == 0) {
            int retPos = FindChildIndexByName(node, leafName);
            if (retPos >= 0) {
                return node.GetChildList()[retPos];
            } else {
                return null;
            }
        }
        int pos = FindChildIndexByName(node, tree[0]);
        tree.RemoveAt(0);
        if (pos >= 0) {
            return FindFromTail(node.GetChildList()[pos], tree, leafName);
        } else {
            return null;
        }
    }

    private int FindChildIndexByName(NodeEntity node, string name) {
        int pos = -1;
        int i = 0;
        node.GetChildList().ForEach(v => {
            if (v.NameEquals(name)) {
                pos = i;
            }
            i++;
        });
        return pos;
    }

    public NodeEntity Clone() {
        NodeEntity ret = new NodeEntity();

        attrList.ForEach(v => {
            ret.AddAttr(v.Clone());
        });
        childList.ForEach(v => {
            ret.AddChild(v.Clone());
        });

        ret.SetNodeName(nodeName);
        ret.SetNodeID(nodeId);
        ret.SetNodeValue(nodeValue);

        return ret;
    }
}